package com.example.logonrmlocal.prova;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class SegundaActivity extends AppCompatActivity {

    RadioButton vermelho;
    RadioButton azul;
    RadioButton verde;
    RadioGroup cor;
    View tela;

    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);

        vermelho = findViewById(R.id.vermelho);
        azul = findViewById(R.id.azul);
        verde = findViewById(R.id.verde);
        cor = findViewById(R.id.cor);
        tela = findViewById(R.id.view);
        sp = getSharedPreferences("config2", MODE_PRIVATE);

        int cor = sp.getInt("cor", 0);

        if(cor ==1){
            tela.setBackgroundColor(Color.RED);
        }else if(cor == 2){
            tela.setBackgroundColor(Color.BLUE);
        }else if(cor == 3){
            tela.setBackgroundColor(Color.GREEN);
        }

    }


    public void salvar(View view) {


        SharedPreferences.Editor editor = sp.edit();
        int valor = cor.getCheckedRadioButtonId();

        switch (valor){
            case R.id.vermelho:
                tela.setBackgroundColor(Color.RED);
                editor.putInt("cor", 1);
                break;

            case R.id.azul:
                tela.setBackgroundColor(Color.BLUE);
                editor.putInt("cor", 2);
                break;

            case R.id.verde:
                tela.setBackgroundColor(Color.GREEN);
                editor.putInt("cor", 3);
                break;
        }
        editor.commit();



        Toast.makeText(this, "Cor alterada", Toast.LENGTH_SHORT).show();

    }
}
