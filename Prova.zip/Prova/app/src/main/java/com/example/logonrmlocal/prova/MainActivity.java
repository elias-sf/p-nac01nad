package com.example.logonrmlocal.prova;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText usuario;
    EditText senha;
    CheckBox logado;

    SharedPreferences sp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usuario = findViewById(R.id.usuario);
        senha = findViewById(R.id.senha);
        logado = findViewById(R.id.logado);
        sp = getSharedPreferences("config", MODE_PRIVATE);

        usuario.setText(sp.getString("usuario", null));
        senha.setText(sp.getString("senha", null));

    }

    public void logar(View view) {
        SharedPreferences.Editor editor = sp.edit();


        if(usuario.getText().toString().equals("FIAP")&& senha.getText().toString().equals("123456")){
            editor.putString("usuario", usuario.getText().toString());
            editor.putString("senha", senha.getText().toString());
            editor.commit();

            Intent i = new Intent(this, SegundaActivity.class);
            startActivity(i);
        }else{
            Toast.makeText(this, "Usuario invalido ", Toast.LENGTH_SHORT).show();
        }



    }
}
